import { redirect } from "next/navigation";

export default function NewResumePage() {
  redirect("/resumes");
}
